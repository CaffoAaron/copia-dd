<!DOCTYPE html>
<!--[if lt IE 7 ]><html class="ie ie6" lang="es"> <![endif]-->
<!--[if IE 7 ]><html class="ie ie7" lang="es"> <![endif]-->
<!--[if IE 8 ]><html class="ie ie8" lang="es"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html lang="es"> <!--<![endif]-->
<head>
	<!-- Basic Page Needs
  ================================================== -->
	<meta charset="utf-8">
	<title>DINAUT | Bolsa Laboral</title>
	<meta name="keywords" content="bolsa laboral dinaut, solicito trabajo, datos de contacto dinaut">
    <meta name="description" content="Bolsa laboral dinaut">
	<meta name="author" content="atipica.pe">
	
    <!-- Mobile Specific Metas
  ================================================== -->
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<!-- CSS
  ================================================== -->
	
    <!-- Web Fonts  -->
    <link href='https://fonts.googleapis.com/css?family=Raleway:400,700,600,500,300' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Oswald:400,700,300' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,700,600,500,300' rel='stylesheet' type='text/css'>
    
    <!-- Theme Style -->
    <link rel="stylesheet" href="css/theme.css">   
    <link rel="stylesheet" href="css/theme-animate.css">   
    <link rel="stylesheet" href="css/theme-elements.css">   
    <link rel="stylesheet" href="css/plugins.css">    
    
    <!-- Skin CSS -->
	<link id="skin" rel="stylesheet" href="css/skins/sun.css">
    <!-- Icon Fonts -->
    <link rel='stylesheet' href='fonts/font-awesome.min.css' type='text/css' media='screen' />    
    
    <!-- Library Css -->
    <link rel="stylesheet" href="css/skeleton.css"> 
    <link rel="stylesheet" href="vendor/flexslider/flexslider.css">
    
    <link rel="stylesheet" href="vendor/isotope/isotope.css">
    <link rel="stylesheet" href="vendor/owl/owl.carousel.css">
    <link rel="stylesheet" href="vendor/prettyPhoto/prettyPhoto.css">
    <link rel="stylesheet" type="text/css" href="vendor/rs-plugin/css/settings.css" media="screen" /> 
    
    <!-- Responsive Theme -->
    <link rel="stylesheet" href="css/theme-responsive.css">
    
    <!-- Library Js -->
	<script src="vendor/modernizr.js"></script>
    
    <!-- Google Map -->
    <script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false"></script>
    
    <!--[if IE]>
        <link rel="stylesheet" href="css/ie.css">
    <![endif]-->
    
    <!--[if lte IE 8]>
        <script src="vendor/respond.js"></script>
    <![endif]-->
    
	<!--[if lt IE 9]>
		<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
	<!-- Favicons
	================================================== -->
	<link rel="shortcut icon" href="images/favicon.png">
	<link rel="apple-touch-icon" href="images/apple-touch-icon.png">
	<link rel="apple-touch-icon" sizes="72x72" href="images/apple-touch-icon-72x72.png">
	<link rel="apple-touch-icon" sizes="114x114" href="images/apple-touch-icon-114x114.png">
</head>  
<body>
	<!-- BOF Loader -->
     <div class="loader">
         <div class="spinner spinner-double-bounce">
              <div class="double-bounce1"></div>
              <div class="double-bounce2"></div>
         </div>
	</div>
    <!-- EOF Loader -->   
    
    <!-- BOF Header -->   

    <header>
        <!-- BOF Top Bar -->
        <div class="jx-header-1">
            <!-- BDF TOOLBAR -->
            <div class="jx-topbar">
                <div class="container">
                    <div class="eight columns left">
                        <div class="jx-left-topbar">DIN Automatización | Soluciones integrales</div>
                    </div>
                    <!-- Left Items -->
                    <div class="eight columns right">
                        <div class="jx-right-topbar">
                            <div class="email left"><i class="fa fa-envelope"></i> mail@dinaut.com</div>
                                <ul class="right">
                                    <li><a href="./admin" target="_blank"><i class="fa fa-user"></i>Acceso Usuarios</a>&nbsp;</li>
								    <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                                </ul>
                                <!-- Social icons-->
                            </div>
                    </div>
                    <!-- Right Items -->
                </div>
            </div>
            <!-- EDF TOOLBAR --> 
            <div class="jx-header header-line">
                <div class="container">
                    <div class="four columns">
                        <div class="jx-header-logo">
                            <a href="index.php"><img src="images/logo1.png" alt="dinaut" /></a>
                         </div>
                        <!-- Logo -->
                    </div>                
                    <div class="twelve columns">
                        <div class="header-info">
                            <ul>
                                <li class="top-space">
                                <div class="icon"><i class="fa fa-map-marker"></i></div>
                                <div class="position">
                                <div class="location">Oficinas</div>
                                <div class="address">PERÚ, BOLIVIA</div>
                                </div>
                                </li>
                                <li class="top-space">
                                <div class="icon"><i class="fa fa-clock-o"></i></div>
                                <div class="position">
                                <div class="time">Horario en Oficina</div>
                                <div class="date">LUN - VIE 7:45 - 17:15</div>
                                </div>
                                </li>
                                <li>
                                    <div class="toll-free-number"> <img src="images/siemens-logo.png"></div>
                                </li> 
                            </ul>
                        </div>
                        <!-- Header Info -->
                    </div>                
	            </div>
            </div>     
        </div>
        <!-- EOF Top Bar -->
        <!-- EDF Header -->
        
        <div class="jx-menu-holder jx-sticky">
        	<div class="container">
                    <div class="header-menu-left">
                      <div class="nav_container">
                            
<ul id="jx-main-menu" class="menu">

	<!-- Item 1 -->

	<li class=""><a href="./index.php" >Inicio</a></li>       

	<!-- Item 2 -->

	<li><a href="./nosotros.php">Nosotros</a></li>

	<!-- Item 3 -->

	<li class="with-sub">

		<a href="#">Nuestra oferta</a>

		<ul class="submenu">     

			<li class="">

				<a href="./productos.php">Productos</a>

			</li>

			<li class="has-child">

				<a href="#">Servicios</a>

				<ul class="submenu">                                        					                                  	                                     

						<li><a href="./montaje_conexiones_electricas.php">Montaje y Conexiones<br> El&eacute;ctricas</a></li>

						<li><a href="./ingenieria_basica_detalle.php">Ingenier&iacute;a B&aacute;sica y de Detalle</a></li>

						<li><a href="./ingenieria_desarrollo_aplicaciones.php">Ingenier&iacute;a de Desarrollo y de<br> Aplicaciones</a></li>

						<li><a href="./comisionamiento_puesta_marcha.php">Comisionamiento y Puesta<br> en Marcha</a></li>

						<li><a href="./proyectos.php">Proyectos</a></li>

						<li><a href="./entrenamiento.php">Entrenamiento</a></li>

				</ul>

			 </li>

		 </ul>

	</li>

	<!-- Item 3 -->

			<li class="with-sub">
			<a href="./proyectos.php">Proyectos</a>
			<ul class="submenu lista-servicio">
				<li><a href="./proyectos.php#agroindustrial" data-filter=".agroindustrial" data-servicio="agroindustrial">Agroindustrial</a></li>
				<li><a href="./proyectos.php#bebidas" data-filter=".bebidas" data-servicio="bebidas">Industria</a></li>
				<li><a href="./proyectos.php#mineria" data-filter=".mineria" data-servicio="mineria">Miner&iacute;a</a></li>
				<li><a href="./proyectos.php#saneamiento" data-filter=".saneamiento" data-servicio="saneamiento">Saneamiento</a></li>
				<li><a href="./proyectos.php#educativo" data-filter=".educativo" data-servicio="educativo">Educaci&oacute;n</a></li>
			</ul>  
		</li>
	
	 <!-- Item 4 -->  

	<li><a href="./entrenamiento.php">Entrenamiento</a></li>

	<!-- Item 5 -->

	<li class="with-sub">

		<a href="#">Contacto</a>

		<ul class="submenu">                                    	                                       

					<li ><a href="./contacto.php">Oficina Per&uacute;</a></li>

					<li ><a href="./contacto_bolivia.php">Oficina Bolivia</a></li>

					<!--<li ><a href="./contacto_ecuador.php">Oficina Ecuador</a></li>-->

					<li ><a href="./bolsa_laboral.php">Bolsa laboral</a></li>

		 </ul>  

	</li>

  </ul>

</div>                                                	                 
                        </div>
                        <!-- EOF Menu -->
                    </div>
                    <!-- MENU -->
                    </div>
    	</div>
        <!-- BOF Main Menu -->
        
        <!-- BOF Titlebar -->
        <br>
        <div class="jx-titlebar">
        	<div class="parallax bg-pos-middle" style="background-image:url('images/bolsa-laboral1.jpg');"></div>  
           <div class="container">
            	<div class="sixteen columns alpha">
                    <div class="jx-page-title">            
                        <div class="jx-breaducrumb"><a href="bolsa_laboral.php" >Bolsa </a> <span>Laboral</span></div>
                    </div>
                </div>       
            </div>                 
        </div>    
        <!-- EOF Titlebar -->
        
	</header>     
    
    <!-- EOF Main Menu -->
    
    <!-- BOF Main Content -->
    <div role="main" class="main no-top-padding">
    
    <!-- History -->
    <div class="jx-container">
    	<div class="container with-sidebar">

    		<div class="sixteen columns right jx-padding omega">
				
               <div class="jx-request-quote jx-grey-bg">
                              	<div class="jx-title jx-uppercase small-text">Ingrese sus datos</div>
                <div class="jx-seperator-hr"></div>
       
               	<form method="post" enctype="multipart/form-data">
               
               	<div class="jx-quote-box">
                
                	<label>Area a postular</label>
                
                	<select name="area" class="select-box">
                      <option value="Logística - Finanzas - Administración">Logística - Finanzas - Administración</option>
                      <option value="Ventas">Ventas</option>
                      <option value="Técnicos e Ingenieros">Técnicos e Ingenieros</option>
                      <option value="Practicantes">Practicantes</option>
                    </select>
                
                </div>
                
                <div class="jx-quote-box">
                
                	<label>País a laborar</label>
                
                	<select name="pais" class="select-box">
                      <option value="peru">Perú</option>
                      <option value="bolivia">Bolivia</option>
                      <option value="ecuador">Ecuador</option>
                     </select>
                
                </div>
                
                <div class="jx-quote-box contact-details">
                
                	<label>Información para contacto</label>                    
                    <div class="jx-contact-fields">
                        <div class="contact-full-name">
                            <input type="text" id="full-name-contact" name="name" placeholder="Nombres y apellidos" class="jx-form-text" />
                            <!-- First Name Textbox -->
                        </div>
                        <div class="contact-email">
                            <input type="text" id="email-contact" name="email" placeholder="Email" class="jx-form-text" data-validation="email"/>
                            <!-- Email Name Textbox -->
                        </div>
                    
                        <div class="contact-subject">
                            <input type="text" id="phone-contact" name="phone" placeholder="Teléfonos" class="jx-form-text" data-validation="required"/>
                            <!-- Subject Textbox -->
                        </div>
                	</div>
                    <div class="contact-full-name">
                        <label>Adjuntar CV</label>
					    <input type="file" name="cv" class="form-control">
                         </div> <br><br> 
                    <div class="contact-submit">
                        
                        <button type="submit">ENVIAR</button>
                        <!-- Submit Button -->
                    </div>
				</div>
               
               </form>
				               </div> 
            </div>
 
            <!-- EDF Main Content -->
            
            <div id="sidebar" class="four columns left jx-padding alpha">
             <div class="jx-sidebar-block mb40">
                    <div class="jx-quote-rquest">
                		   <div class="jx-title"><i class="line-icon icon-user"></i>Hola Postulante</div>
                           <p>Nos gustaría que pertenezcas a nuestro equipo de trabajo. Para lo cual, llena los datos en el formulario y adjunta tu CV.</p>
                       </div>
                </div>
                
                <div class="jx-office-widget jx-sidebar-block mb40">
                    <div class="jx-section-title-2">
                        <div class="jx-title jx-uppercase small-text">Contacto de RRHH</div>
                        <div class="jx-seperator-hr"></div>
                    </div>
                    <!-- Section title -->                         
                    
                    <div class="jx-sidebar-address">
                        <ul>
                            <li>
                            <i class="line-icon icon-location"></i>
                            <div>Av. Aurelio Garcia y Garcia 1592, Lima 01</div>
                            </li>
                            <li>
                            <i class="line-icon icon-mobile"></i>
                            <div class="tel"><strong>Tel :</strong> +51 (1) 564 - 5521</div>
                            </li>
                            <li>
                            <i class="line-icon icon-globe"></i>
                            <div class="email"><strong>Email :</strong> mail@dinaut.com</div>
                            </li>
                        </ul>
                    </div>
                    <!-- Contact Address -->
                </div> 
                
            
            
            </div>            
			<!-- EDF Side Bar Content -->


        </div>
    </div>
    <!-- EOF Hisory-->
    

    

    </div>
    <!-- EOF Main Content -->
    
    
    <!-- BOF FOOTER -->
    
    <footer class="jx-footer-section">
		<div class="jx-footer-1">        
           <!-- BDF widget FOOTER -->        
            <div class="jx-footer jx-container">
                <div class="container">
                    <!-- BOF Footer widget #1 -->
                    <div class="four columns">
                        <div class="widget">             
                            <div class="jx-about">
                            <div class="jx-footer-title">Certificaciones</div>
                            <img src="images/sgs-logo.png" alt="sgs" />
                            <img src="images/bureau_logo.png" alt="dinaut" /> 
                            <!-- Content -->
                            </div>
                         </div>
                        <!-- Newsletter Subscribe -->
                    </div>                
                    <!-- EOF Footer widget #1 -->
                    <!-- BOF Footer widget #2-->
                    <div class="four columns">
                    	<div class="widget">
                            <div class="jx-footer-title">Bolsa Laboral</div>
                            <!-- widget Title -->
                            <div class="jx-widget-recent-post">

                                <ul>
                                   <li>
                                       <div class="image"><img src="images/bolsa-laboral.jpg" alt="bolsa-laboral" /></div>
                                         <div class="post-content">
                                            <div class="date">Nos gustaria que seas parte de nuestro equipo. Déjenos sus datos ahora.</div>
                                            </div>
                                    </li>
                                </ul>
                               <div class="jx-btn jx-black"> 
                                    <a href="bolsa_laboral.php" class="jx-btn-default">
                                       <span>	
                                            <i class="btn-icon-left fa fa-mail-forward"></i>
                                            <span>Postular</span>
                                            <i class="btn-icon-right fa fa-mail-forward"></i>
                                        </span>
                                    </a>
                            	</div>
                            </div>
                            <!-- Recent Post -->
                        </div>
                    </div>                
                    <!-- EOF Footer widget #2-->
                    <!-- BOF Footer widget #3 -->
                    <div class="four columns">
                          <div class="widget">                
                            <div class="jx-footer-title">Video</div>
                            <iframe src="https://player.vimeo.com/video/216543715" width="640" height="160" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>
                            <p><a href="https://vimeo.com/216543715">Solution Partner Siemens - Dinaut</a>.</p>               
						</div>
                      </div>                
                    <!-- EOF Footer widget #3-->
                    <!-- BOF Footer widget #4 -->
                    <div class="four columns">
                          <div class="widget">
                            <div class="jx-footer-title">Contacto Perú</div>
                            <!-- widget Title -->                         
                            <div class="jx-footer-address">
                               <ul>
                                    <li>
                                    <i class="line-icon icon-location"></i>
                                    <div>Av. Aurelio Garcia y Garcia 1592, Lima 01</div>
                                    </li>
                                    <li>
                                    <i class="line-icon icon-mobile"></i>
                                    <div class="tel"><strong>Tel :</strong> +51 (1) 564 - 5521</div>
                                    </li>
                                    <li>
                                    <i class="line-icon icon-globe"></i>
                                    <div class="email"><strong>Email :</strong> mail@dinaut.com</div>
                                    </li>
                                </ul>
                           </div>
                            <!-- Contact Address -->
                        </div>                                         
                    </div>                  
                    <!-- EOF Footer widget #4 -->
                </div>
            </div>
            <!-- EDF widget FOOTER -->
            <!-- BDF SUB FOOTER -->        
            <div class="jx-sub-footer jx-container">
                <div class="container"> 
                    <div class="eight columns">
                        <div class="jx-copy-right">Copyright © 2019 Diseñado por <a href="http://atipicapublicidad.com" target="_blank">Atípica</a></div>
                    </div>                
					<!-- Copyright Text -->
                    <div class="eight columns">
                       <div class="jx-footer-social-icon">
                        <ul>                            
                            <li class="facebook">
                            <a href="https://web.facebook.com/Dinautomatizacion" target="_blank"><i class="fa fa-facebook"></i></a>
                            </li>                        
                            <li class="youtube">
                            <a href="http://www.youtube.com/#" target="_blank"><i class="fa fa-youtube"></i></a>
                            </li>
                            <li class="googleplus">
                            <a href="http://www.googleplus.com/#" target="_blank"><i class="fa fa-google-plus"></i></a>
                            </li>
                        </ul>
                     </div>
                    </div>
                    <!-- Social Icons -->                
                </div>
            </div>
            <!-- EDF SUB FOOTER -->        
        </div>        
    </footer>
     
    <!-- EOF FOOTER -->

    <!-- Footer -->
    
	<script type="text/javascript" src="vendor/jquery.js"></script>
    <script type="text/javascript" src="js/plugins.js"></script>
	<script type="text/javascript" src="vendor/respond.js"></script>
    <script type="text/javascript" src="vendor/jquery.appear.js"></script>    
    <script type="text/javascript" src="vendor/prettyPhoto/jquery.prettyPhoto.js"></script>
    <script type="text/javascript" src="vendor/isotope/jquery.isotope.min.js"></script>
    <script type='text/javascript' src='vendor/form-validator/jquery.form-validator.min.js'></script>
    <script type="text/javascript" src="vendor/flexslider/jquery.flexslider.js"></script>	
    <script type="text/javascript" src="vendor/rs-plugin/js/jquery.themepunch.tools.min.js"></script>
    <script type="text/javascript" src="vendor/rs-plugin/js/jquery.themepunch.revolution.min.js"></script>
    
   <!-- Home JS -->
	<script src="js/custom/home.js"></script>
    
    <!-- Theme Initializer -->
	<script src="js/theme.js"></script>
    
  <!-- WhatsHelp.io widget -->
<script type="text/javascript">
    (function () {
        var options = {
            whatsapp: "+51997598006", // WhatsApp number
            call_to_action: "Contáctanos", // Call to action
            position: "right", // Position may be 'right' or 'left'
        };
        var proto = document.location.protocol, host = "whatshelp.io", url = proto + "//static." + host;
        var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = url + '/widget-send-button/js/init.js';
        s.onload = function () { WhWidgetSendButton.init(host, proto, options); };
        var x = document.getElementsByTagName('script')[0]; x.parentNode.insertBefore(s, x);
    })();
</script>
<!-- /WhatsHelp.io widget -->    
    
</body>
</html>