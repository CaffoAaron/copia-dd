<!DOCTYPE html>
<!--[if lt IE 7 ]><html class="ie ie6" lang="es"> <![endif]-->
<!--[if IE 7 ]><html class="ie ie7" lang="es"> <![endif]-->
<!--[if IE 8 ]><html class="ie ie8" lang="es"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html lang="es"> <!--<![endif]-->
<head>
	<!-- Basic Page Needs
  ================================================== -->
	<meta charset="utf-8">
	<title>DINAUT | Soluciones integrales en automatización, intrumentacion y electricidad industrial</title>
	<meta name="keywords" content="dinaut, din automatizacion, soluciones integrales, industrial, electricidad industrial, plantas industriales, automatizacion en lima">
    <meta name="description" content="Dinaut - Soluciones integrales en automatización, instrumentación y electricidad industrial.">
	<meta name="author" content="atipica.pe">	
   <!-- Mobile Specific Metas
  ================================================== -->
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<!-- CSS
  ================================================== -->
    <!-- Web Fonts  -->
    <link href='https://fonts.googleapis.com/css?family=Raleway:400,700,600,500,300' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Oswald:400,700,300' rel='stylesheet' type='text/css'>
	<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,700,600,500,300' rel='stylesheet' type='text/css'>
    <!-- Theme Style -->
    <link rel="stylesheet" href="css/theme.css">   
    <link rel="stylesheet" href="css/theme-animate.css">   
    <link rel="stylesheet" href="css/theme-elements.css">   
    <link rel="stylesheet" href="css/plugins.css">    
    <!-- Skin CSS -->
	<link id="skin" rel="stylesheet" href="css/skins/sun.css">
    <!-- Icon Fonts -->
    <link rel='stylesheet' href='fonts/font-awesome.min.css' type='text/css' media='screen' />    
    <!-- Library Css -->
    <link rel="stylesheet" href="css/skeleton.css"> 
    <link rel="stylesheet" href="vendor/flexslider/flexslider.css">
    <link rel="stylesheet" href="vendor/isotope/isotope.css">
    <link rel="stylesheet" href="vendor/owl/owl.carousel.css">
    <link rel="stylesheet" href="vendor/prettyPhoto/prettyPhoto.css">
    <link rel="stylesheet" type="text/css" href="vendor/rs-plugin/css/settings.css" media="screen" /> 
  	<link rel="stylesheet" href="css/animate.css">  
	<!-- Responsive Theme -->
    <link rel="stylesheet" href="css/theme-responsive.css">
    <!-- Library Js -->
	<script src="vendor/modernizr.js"></script>
    <!--[if IE]>
        <link rel="stylesheet" href="css/ie.css">
    <![endif]-->
    <!--[if lte IE 8]>
        <script src="vendor/respond.js"></script>
    <![endif]-->
	<!--[if lt IE 9]>
		<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
	<!-- Favicons
	================================================== -->
	<link rel="shortcut icon" href="images/favicon.png">
	<link rel="apple-touch-icon" href="images/apple-touch-icon.png">
	<link rel="apple-touch-icon" sizes="72x72" href="images/apple-touch-icon-72x72.png">
	<link rel="apple-touch-icon" sizes="114x114" href="images/apple-touch-icon-114x114.png">	
</head>  

<body>

	<!-- BOF Loader -->
     <div class="loader">
         <div class="spinner spinner-double-bounce">
              <div class="double-bounce1"></div>
              <div class="double-bounce2"></div>
         </div>
	</div>
    <!-- EOF Loader -->
    <!-- BOF Header -->   
    <header>
        <!-- BOF Top Bar -->
        <div class="jx-header-1">
            <!-- BDF TOOLBAR -->
            <div class="jx-topbar">
                <div class="container">
                    <div class="eight columns left">
                        <div class="jx-left-topbar">DIN Automatización | Soluciones integrales</div>
                    </div>
                    <!-- Left Items -->
                    <div class="eight columns right">
                        <div class="jx-right-topbar">
                            <div class="email left"><i class="fa fa-envelope"></i> mail@dinaut.com</div>
                                <ul class="right">
                                    <li><a href="./admin" target="_blank"><i class="fa fa-user"></i>Acceso Usuarios</a>&nbsp;</li>
								    <li><a href="https://www.facebook.com/Dinautomatizacion"><i class="fa fa-facebook"></i></a></li>
								    <li><a href="https://www.instagram.com/dinaut_peru/"><i class="fa fa-instagram"></i></a></li>
                                </ul>
                                <!-- Social icons-->
                            </div>
                    </div>
                    <!-- Right Items -->
                </div>
            </div>
            <!-- EDF TOOLBAR --> 
            <div class="jx-header header-line">
                <div class="container">
                    <div class="four columns">
                        <div class="jx-header-logo">
                            <a href="index.php"><img src="images/logo1.png" alt="dinaut" /></a>
                         </div>
                        <!-- Logo -->
                    </div>                
                    <div class="twelve columns">
                        <div class="header-info">
                            <ul>
                                <li class="top-space">
                                <div class="icon"><i class="fa fa-map-marker"></i></div>
                                <div class="position">
                                <div class="location">Oficinas</div>
                                <div class="address">PERÚ - BOLIVIA</div>
                                </div>
                                </li>
                                <li class="top-space">
                                <div class="icon"><i class="fa fa-clock-o"></i></div>
                                <div class="position">
                                <div class="time">Horario en Oficina</div>
                                <div class="date">LUN - VIE 7:45 - 17:15</div>
                                </div>
                                </li>
                                <li>
                                    <div class="toll-free-number"> <img src="images/siemens-logo.png"></div>
                                </li> 
                            </ul>
                        </div>
                        <!-- Header Info -->
                    </div>                
	            </div>
            </div>     
        </div>
        <!-- EOF Top Bar -->
        <!-- EDF Header -->
        <div class="jx-menu-holder jx-sticky">
        	<div class="container">
                    <div class="header-menu-left">
                      <div class="nav_container">
                            
<ul id="jx-main-menu" class="menu">

	<!-- Item 1 -->

	<li class="current"><a href="./index.php" >Inicio</a></li>       

	<!-- Item 2 -->

	<li><a href="./nosotros.php">Nosotros</a></li>

	<!-- Item 3 -->

	<li class="with-sub">

		<a href="#">Nuestra oferta</a>

		<ul class="submenu">     

			<li class="">

				<a href="./productos.php">Productos</a>

			</li>

			<li class="has-child">

				<a href="#">Servicios</a>

				<ul class="submenu">                                        					                                  	                                     

						<li><a href="./montaje_conexiones_electricas.php">Montaje y Conexiones<br> El&eacute;ctricas</a></li>

						<li><a href="./ingenieria_basica_detalle.php">Ingenier&iacute;a B&aacute;sica y de Detalle</a></li>

						<li><a href="./ingenieria_desarrollo_aplicaciones.php">Ingenier&iacute;a de Desarrollo y de<br> Aplicaciones</a></li>

						<li><a href="./comisionamiento_puesta_marcha.php">Comisionamiento y Puesta<br> en Marcha</a></li>

						<li><a href="./proyectos.php">Proyectos</a></li>

						<li><a href="./entrenamiento.php">Entrenamiento</a></li>

				</ul>

			 </li>

		 </ul>

	</li>

	<!-- Item 3 -->

			<li class="with-sub">
			<a href="./proyectos.php">Proyectos</a>
			<ul class="submenu lista-servicio">
				<li><a href="./proyectos.php#agroindustrial" data-filter=".agroindustrial" data-servicio="agroindustrial">Agroindustrial</a></li>
				<li><a href="./proyectos.php#bebidas" data-filter=".bebidas" data-servicio="bebidas">Industria</a></li>
				<li><a href="./proyectos.php#mineria" data-filter=".mineria" data-servicio="mineria">Miner&iacute;a</a></li>
				<li><a href="./proyectos.php#saneamiento" data-filter=".saneamiento" data-servicio="saneamiento">Saneamiento</a></li>
				<li><a href="./proyectos.php#educativo" data-filter=".educativo" data-servicio="educativo">Educaci&oacute;n</a></li>
			</ul>  
		</li>
	
	 <!-- Item 4 -->  

	<li><a href="./entrenamiento.php">Entrenamiento</a></li>

	<!-- Item 5 -->

	<li class="with-sub">

		<a href="#">Contacto</a>

		<ul class="submenu">                                    	                                       

					<li ><a href="./contacto.php">Oficina Per&uacute;</a></li>

					<li ><a href="./contacto_bolivia.php">Oficina Bolivia</a></li>

					<!--<li ><a href="./contacto_ecuador.php">Oficina Ecuador</a></li>-->

					<li ><a href="./bolsa_laboral.php">Bolsa laboral</a></li>

		 </ul>  

	</li>

  </ul>

</div>          	                  
                        </div>
                        <!-- EOF Menu -->
                    </div>
                    <!-- MENU -->
                    </div>
    	</div>
        <!-- BOF Main Menu -->
        <!-- BOF Slider -->
        <div class="jx-slider">        
            <div class="jx-rev-slider-holder">           
               <div class="tp-banner-container home-slider-1">
                    <div class="tp-banner" >
                        <ul>
                            <!-- SLIDE#1 -->
                            <li data-transition="slideleft" data-slotamount="7" data-masterspeed="500">
                                <!-- MAIN IMAGE -->
                                <img src="images/slider-bebidas.jpg"  alt="slidebg1"  data-bgfit="cover" data-bgposition="center top" data-bgrepeat="no-repeat">
                                <!-- LAYERS -->                               
                                <!-- LAYER NR. 1 -->
                            <div class="jx-caption-big-1 tp-caption grey_regular_18 customin tp-resizeme rs-parallaxlevel-0"
                                        data-x="-105"
                                        data-y="250" 
                                        data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
                                        data-speed="500"
                                        data-start="800"
                                        data-easing="Power3.easeInOut"
                                        data-splitin="none"
                                        data-splitout="none"
                                        data-elementdelay="0.05"
                                        data-endelementdelay="0.1"
                                        style="z-index: 9; max-width: auto; max-height: auto; white-space: nowrap;">Sector Bebidas y Alimentos</div>
                             <div class="jx-caption-big-icon tp-caption grey_regular_18 customin tp-resizeme rs-parallaxlevel-0"
                                        data-x="393"
                                        data-y="250" 
                                        data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
                                        data-speed="500"
                                        data-start="800"
                                        data-easing="Power3.easeInOut"
                                        data-splitin="none"
                                        data-splitout="none"
                                        data-elementdelay="0.05"
                                        data-endelementdelay="0.1"
                                        style="z-index: 9; max-width: auto; max-height: auto; white-space: nowrap;"></div>           
                             <!-- LAYER NR. 2 -->
                            <div class="jx-caption-big-2 tp-caption grey_regular_18 customin tp-resizeme rs-parallaxlevel-0"
                                        data-x="-105"
                                        data-y="340" 
                                        data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
                                        data-speed="500"
                                        data-start="1100"
                                        data-easing="Power3.easeInOut"
                                        data-splitin="none"
                                        data-splitout="none"
                                        data-elementdelay="0.05"
                                        data-endelementdelay="0.1"

                                        style="z-index: 9">PCS7 BRAUMAT y PCS7 Batch, PLC+SCADA con softwares para <br>
									     medir KPI, eficiencia de máquina y gestión de energía en áreas <br>de elaboración y envasado.</div>

                             <!-- LAYER NR. 3 -->
                            </li>
                            <li data-transition="slideleft" data-slotamount="7" data-masterspeed="500">
                                <!-- MAIN IMAGE -->
                                <img src="images/slider-cementos.jpg" alt="slidebg1"  data-bgfit="cover" data-bgposition="center top" data-bgrepeat="no-repeat">
                                <!-- LAYERS -->
                                <!-- LAYER NR. 1 -->
                            <div class="jx-caption-big-1 tp-caption grey_regular_18 customin tp-resizeme rs-parallaxlevel-0"
                                        data-x="-105"
                                        data-y="250" 
                                        data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
                                        data-speed="500"
                                        data-start="800"
                                        data-easing="Power3.easeInOut"
                                        data-splitin="none"
                                        data-splitout="none"
                                        data-elementdelay="0.05"
                                        data-endelementdelay="0.1"
                                        style="z-index: 9; max-width: auto; max-height: auto; white-space: nowrap;">Sector Cemento</div>
                             <div class="jx-caption-big-icon tp-caption grey_regular_18 customin tp-resizeme rs-parallaxlevel-0"
                                        data-x="396"
                                        data-y="250" 
                                        data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
                                        data-speed="500"
                                        data-start="800"
                                        data-easing="Power3.easeInOut"
                                        data-splitin="none"
                                        data-splitout="none"
                                        data-elementdelay="0.05"
                                        data-endelementdelay="0.1"
                                        style="z-index: 9; max-width: auto; max-height: auto; white-space: nowrap;"></div>           

                             <!-- LAYER NR. 2 -->
                            <div class="jx-caption-big-2 tp-caption grey_regular_18 customin tp-resizeme rs-parallaxlevel-0"
                                        data-x="-105"
                                        data-y="340" 
                                        data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
                                        data-speed="500"
                                        data-start="1100"
                                        data-easing="Power3.easeInOut"
                                        data-splitin="none"
                                        data-splitout="none"
                                        data-elementdelay="0.05"
                                        data-endelementdelay="0.1"
                                        style="z-index: 9">Sistemas de automatización PLC + SCADA y PCS7 CEMAT <br>
										para hornos, secadores y molinos de plantas cementeras.</div>

                             <!-- LAYER NR. 3 -->
                            </li>
                            <li data-transition="slideleft" data-slotamount="7" data-masterspeed="500">
                                <!-- MAIN IMAGE -->
                                <img src="images/slider-minera.jpg"  alt="slidebg1"  data-bgfit="cover" data-bgposition="center top" data-bgrepeat="no-repeat">
                                <!-- LAYERS -->                               
                                <!-- LAYER NR. 1 -->
                            <div class="jx-caption-big-1 tp-caption grey_regular_18 customin tp-resizeme rs-parallaxlevel-0"
                                        data-x="-105"
                                        data-y="250" 
                                        data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
                                        data-speed="500"
                                        data-start="800"
                                        data-easing="Power3.easeInOut"
                                        data-splitin="none"
                                        data-splitout="none"
                                        data-elementdelay="0.05"
                                        data-endelementdelay="0.1"
                                        style="z-index: 9; max-width: auto; max-height: auto; white-space: nowrap;">Sector Minería</div>
                             <div class="jx-caption-big-icon tp-caption grey_regular_18 customin tp-resizeme rs-parallaxlevel-0"
                                        data-x="393"
                                        data-y="250" 
                                        data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
                                        data-speed="500"
                                        data-start="800"
                                        data-easing="Power3.easeInOut"
                                        data-splitin="none"
                                        data-splitout="none"
                                        data-elementdelay="0.05"
                                        data-endelementdelay="0.1"
                                        style="z-index: 9; max-width: auto; max-height: auto; white-space: nowrap;"></div>           
                             <!-- LAYER NR. 2 -->
                            <div class="jx-caption-big-2 tp-caption grey_regular_18 customin tp-resizeme rs-parallaxlevel-0"
                                        data-x="-105"
                                        data-y="340" 
                                        data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
                                        data-speed="500"
                                        data-start="1100"
                                        data-easing="Power3.easeInOut"
                                        data-splitin="none"
                                        data-splitout="none"
                                        data-elementdelay="0.05"
                                        data-endelementdelay="0.1"

                                        style="z-index: 9">Automatización de pozas de lixiviación y bombeo, chancado,
										celdas de<br> flotación, merril crowe, molienda, concentradora, refinería y relaves.</div>

                             <!-- LAYER NR. 3 -->
                            </li>
                            <li data-transition="slideleft" data-slotamount="7" data-masterspeed="500">
                                <!-- MAIN IMAGE -->
                                <img src="images/slider-alcoholero.jpg"  alt="slidebg1"  data-bgfit="cover" data-bgposition="center top" data-bgrepeat="no-repeat">
                                <!-- LAYERS -->                               
                                <!-- LAYER NR. 1 -->
                            <div class="jx-caption-big-1 tp-caption grey_regular_18 customin tp-resizeme rs-parallaxlevel-0"
                                        data-x="-105"
                                        data-y="250" 
                                        data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
                                        data-speed="500"
                                        data-start="800"
                                        data-easing="Power3.easeInOut"
                                        data-splitin="none"
                                        data-splitout="none"
                                        data-elementdelay="0.05"
                                        data-endelementdelay="0.1"
                                        style="z-index: 9; max-width: auto; max-height: auto; white-space: nowrap;">Sector Agroindustrial</div>
                             <div class="jx-caption-big-icon tp-caption grey_regular_18 customin tp-resizeme rs-parallaxlevel-0"
                                        data-x="393"
                                        data-y="250" 
                                        data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
                                        data-speed="500"
                                        data-start="800"
                                        data-easing="Power3.easeInOut"
                                        data-splitin="none"
                                        data-splitout="none"
                                        data-elementdelay="0.05"
                                        data-endelementdelay="0.1"
                                        style="z-index: 9; max-width: auto; max-height: auto; white-space: nowrap;"></div>           
                             <!-- LAYER NR. 2 -->
                            <div class="jx-caption-big-2 tp-caption grey_regular_18 customin tp-resizeme rs-parallaxlevel-0"
                                        data-x="-105"
                                        data-y="340" 
                                        data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
                                        data-speed="500"
                                        data-start="1100"
                                        data-easing="Power3.easeInOut"
                                        data-splitin="none"
                                        data-splitout="none"
                                        data-elementdelay="0.05"
                                        data-endelementdelay="0.1"

                                        style="z-index: 9">Sistemas de control distribuido DCS, instrumentación y CCM's para área <br>de elaboración de 		                                        azúcar, alcohol, plantas de generación de vapor y<br> energía eléctrica.</div>

                             <!-- LAYER NR. 3 -->
                            </li>
                            <li data-transition="slideleft" data-slotamount="7" data-masterspeed="500">
                                <!-- MAIN IMAGE -->
                                <img src="images/slider-saneamiento.jpg"  alt="slidebg1"  data-bgfit="cover" data-bgposition="center top" data-bgrepeat="no-repeat">
                                <!-- LAYERS -->                               
                                <!-- LAYER NR. 1 -->
                            <div class="jx-caption-big-1 tp-caption grey_regular_18 customin tp-resizeme rs-parallaxlevel-0"
                                        data-x="-105"
                                        data-y="250" 
                                        data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
                                        data-speed="500"
                                        data-start="800"
                                        data-easing="Power3.easeInOut"
                                        data-splitin="none"
                                        data-splitout="none"
                                        data-elementdelay="0.05"
                                        data-endelementdelay="0.1"
                                        style="z-index: 9; max-width: auto; max-height: auto; white-space: nowrap;">Sector Aguas y Saneamiento </div>
                             <div class="jx-caption-big-icon tp-caption grey_regular_18 customin tp-resizeme rs-parallaxlevel-0"
                                        data-x="393"
                                        data-y="250" 
                                        data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
                                        data-speed="500"
                                        data-start="800"
                                        data-easing="Power3.easeInOut"
                                        data-splitin="none"
                                        data-splitout="none"
                                        data-elementdelay="0.05"
                                        data-endelementdelay="0.1"
                                        style="z-index: 9; max-width: auto; max-height: auto; white-space: nowrap;"></div>           
                             <!-- LAYER NR. 2 -->
                            <div class="jx-caption-big-2 tp-caption grey_regular_18 customin tp-resizeme rs-parallaxlevel-0"
                                        data-x="-105"
                                        data-y="340" 
                                        data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
                                        data-speed="500"
                                        data-start="1100"
                                        data-easing="Power3.easeInOut"
                                        data-splitin="none"
                                        data-splitout="none"
                                        data-elementdelay="0.05"
                                        data-endelementdelay="0.1"

                                        style="z-index: 9">Automatización, control, fuerza, instrumentación y telemetría
										para <br>sistemas hídricos con pozos, cisternas, reservorios, PTAP y PTAR.</div>

                             <!-- LAYER NR. 3 -->
                            </li>
                            <!-- SLIDE#1 -->
                            <li data-transition="slideleft" data-slotamount="7" data-masterspeed="500">
                                <!-- MAIN IMAGE -->
                                <img src="images/slider3.jpg"  alt="slidebg1"  data-bgfit="cover" data-bgposition="center center" data-bgrepeat="no-repeat">
                                <!-- LAYERS -->
                                <!-- LAYER NR. 1 -->
                            <div class="jx-caption-big-1 tp-caption grey_regular_18 customin tp-resizeme rs-parallaxlevel-0"
                                        data-x="-105"
                                        data-y="250" 
                                        data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
                                        data-speed="500"
                                        data-start="800"
                                        data-easing="Power3.easeInOut"
                                        data-splitin="none"
                                        data-splitout="none"
                                        data-elementdelay="0.05"
                                        data-endelementdelay="0.1"
                                        style="z-index: 9; max-width: auto; max-height: auto; white-space: nowrap;">Sector Educativo</div>
                             <div class="jx-caption-big-icon tp-caption grey_regular_18 customin tp-resizeme rs-parallaxlevel-0"
                                        data-x="396"
                                        data-y="250" 
                                        data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
                                        data-speed="500"
                                        data-start="800"
                                        data-easing="Power3.easeInOut"
                                        data-splitin="none"
                                        data-splitout="none"
                                        data-elementdelay="0.05"
                                        data-endelementdelay="0.1"
                                        style="z-index: 9; max-width: auto; max-height: auto; white-space: nowrap;"></div>           
                                       
                             <!-- LAYER NR. 2 -->

                            <div class="jx-caption-big-2 tp-caption grey_regular_18 customin tp-resizeme rs-parallaxlevel-0"
                                        data-x="-105"
                                        data-y="340" 
                                        data-customin="x:0;y:0;z:0;rotationX:0;rotationY:0;rotationZ:0;scaleX:0;scaleY:0;skewX:0;skewY:0;opacity:0;transformPerspective:600;transformOrigin:50% 50%;"
                                        data-speed="500"
                                        data-start="1100"
                                        data-easing="Power3.easeInOut"
                                        data-splitin="none"
                                        data-splitout="none"
                                        data-elementdelay="0.05"
                                        data-endelementdelay="0.1"
                                        style="z-index: 9">Módulos educativos y plantas de proceso multivariable con sistemas PLC +<br>
									    SCADA, DCS, Instrumentación, redes industriales, control de velocidad y <br>sistemas
									    de posicionamiento</div>
                            <!-- LAYER NR. 3 -->
                            </li>                                              
                          </ul>
                    </div>
                </div>   
            </div>                 
        </div>    
        <!-- BOF Slider -->
	</header>     
    <!-- EOF Main Menu -->
    <!-- BOF Main Content -->
    <div role="main" class="main no-top-padding">
        <!--  BOF TAGLINE ACTION BOX  # 2 -->
            <div class="jx-container">                
                <div class="jx-tagline-box-3">
                	<div class="jx-shape-left"></div>
                    <div class="jx-shape-right"></div>
                    <div class="container"> 
                        <div class="thirteen columns">
                            <div class="box-content">
                                <h6>Fundada en el año 1997, con amplia experiencia en soluciones y automatización de plantas industriales</h6>
                            </div>
                        <!-- Content -->
                        </div>
                        <div class="three columns">
                            <div class="button"><a href="./nosotros.php">Conocer mas</a></div>
                            <!-- Button -->
                        </div>            
                    </div>
                </div> 
            </div>
         <!--  BOF TAGLINE ACTION BOX  # 2 -->
         
       	 <!-- BDF PROJECT IN PROGRESS-->        
           <div class="jx-container jx-white-bg jx-container-badge">
              <div class="container jx-padding"> 
                <div class="jx-section-title-1">
                <div class="row"></div>
                <div class="row"></div>            
                    <div class="jx-seperator-icon"><i class="fa fa-chevron-down"></i></div>
                    <div class="jx-title-position">
                        <div class="jx-left-border"></div>
                        <div class="jx-title jx-uppercase">Proyectos en ejecución</div>
                        <div class="jx-right-border"></div>
                    </div>
                    <div class="jx-subtitle">A continuación, mostramos algunos de nuestros últimos proyectos ejecutados a los 6 sectores más importantes en la industria peruana e internacional.</div>  
                </div> 
                <!-- Section Title --> 
								                <div class="jx-project-progress">
									<div class="item-destacado">																			
                   <div class="eight columns">                        
                    <div class="jx-project-view-image">
                    <div class="image imagen"><img src="galeria/proyectos-ejecucion/54dcc4_proyecto-ecuador_Mesa de trabajo 1.jpg" /></div>
                        <!-- Image -->
                        <div class="image-hover"></div>
                           
                        <div class="jx-percentage">
                            <div  class="jx-count-up count-number porcentaje">75</div><span>%</span>
                            <div class="progress">Completado</div>
                        </div>
                        <!--  Image hover Progress -->
                    </div>
                    <!-- Project Hover Image -->
                        
                    </div>
                    
                    <div class="eight columns">                
                        <div class="item ">
                            
                            <div class="jx-project-view-contents">                            	
                            	<div class="title titulo">Automatización e Integración del Proyecto Bicis en planta</div>
                                <!-- Title -->
                                <div class="skillbar">
                                    <div class="percent-bg" style="width:75%;"></div>
                                </div>
                                    
                                <!-- Skillbar -->
                                
                                <div class="description detalle"><p>En Dinaut&nbsp;, iniciamos el PROYECTO MULTIDISCIPLINARIO Sistema Virtualizado en PCS7 V9 de Siemens, destinado para la empresa Inbalnor de Ecuador.&nbsp;<br>Bajo los esquemas de la industria 4.0, DIN AUTOMATIZACIÓN sigue marcando la vanguardia tecnológica a nivel nacional e internacional.</p></div>
    
                                <ul class="jx-bg-alternate">
																	<li><strong>Cliente :</strong> <span class="cliente">INBALNOR</span></li>
                                    <li><strong>Localización :</strong> <span class="localizacion">Ecuador</li>
                                    <li><strong>Año - Expedición:</strong> <span class="ano">2021</li>
                                  </ul>
                            	<!-- Details -->                               
                            </div>
                            <!-- Right Position -->
                         </div>
											  <!--
                         <div class="jx-btn jx-black"> 
                                    <a href="proyectos.php" class="jx-btn-default">
                                       <span>	
                                            <i class="btn-icon-left fa fa-mail-forward"></i>
                                            <span>Mas proyectos</span>
                                            <i class="btn-icon-right fa fa-mail-forward"></i>
                                        </span>
                                    </a>
                            	</div>                    
                        <!--Item -->
                    </div>
									</div>
                    
					<!-- Project in Progress View -->                    
                    
                    <div class="row"></div>
                    <div class="row"></div>
										                    <div class="one-third columns">
                    
                        <div class="item proyecto">
                        
                            <div class="jx-project-image">
                            
                                <div class="image imagen"><img src="galeria/proyectos-ejecucion/2fe495_cesur-web.jpg"></div>
                        		<!-- Image -->
                                <div class="image-hover"></div>
                                   
                                <div class="jx-percentage">
                                    <div  class="jx-count-up count-number porcentaje">97</div><span>%</span>
                                    <div class="progress">Progreso</div>
                                </div>
                            	<!--  Image hover Progress -->
                            </div>
                            <!-- Project Hover Image -->
                            
                            <div class="jx-project-contents">
                            
                            	<div class="title titulo">Integración de sistemas auxiliares</div>
                                <!-- Title -->
                                <div class="skillbar">
                                    <div class="percent-bg" style="width:97%;"></div>
                                </div>
                                <div class="description detalle" style="display:none;"><p>Integración de sistemas auxiliares a hornos de Cal Maerz</p><p>Servicio ejecutado para la empresa CESUR con sistemas de control distribuido DCS SIEMENS PCS7 Librerias Polcid.</p></div>
                                <!-- Skillbar -->
    
                                <ul>
                                <li><strong>Cliente :</strong> <span class="cliente">Cemento Sur S.A.</span></li>
                                <li><strong>Localización :</strong> <span class="localizacion">PERU</span></li>
                                <li><strong>Año Exp:</strong> <span class="ano">2021</span></li>
                                </ul>
                            	<!-- Details -->                               
                            </div>
                            <!-- Right Position -->
                         
                        </div>                    
                        <!--Item -->
                    
                    </div>
									                     <div class="one-third columns">
                    
                        <div class="item proyecto">
                        
                            <div class="jx-project-image">
                            
                                <div class="image imagen"><img src="galeria/proyectos-ejecucion/9e838e_eltoro-web.jpg"></div>
                        		<!-- Image -->
                                <div class="image-hover"></div>
                                   
                                <div class="jx-percentage">
                                    <div  class="jx-count-up count-number porcentaje">100</div><span>%</span>
                                    <div class="progress">Progreso</div>
                                </div>
                            	<!--  Image hover Progress -->
                            </div>
                            <!-- Project Hover Image -->
                            
                            <div class="jx-project-contents">
                            
                            	<div class="title titulo">Automatización industrial</div>
                                <!-- Title -->
                                <div class="skillbar">
                                    <div class="percent-bg" style="width:100%;"></div>
                                </div>
                                <div class="description detalle" style="display:none;"><p>Proyecto de Automatización, suministro y configuración del Sistema de control para la nueva planta de procesos ADR - Proyecto Minero "El Toro".</p></div>
                                <!-- Skillbar -->
    
                                <ul>
                                <li><strong>Cliente :</strong> <span class="cliente">Corporación del Centro SAC</span></li>
                                <li><strong>Localización :</strong> <span class="localizacion">PERU</span></li>
                                <li><strong>Año Exp:</strong> <span class="ano">2021</span></li>
                                </ul>
                            	<!-- Details -->                               
                            </div>
                            <!-- Right Position -->
                         
                        </div>                    
                        <!--Item -->
                    
                    </div>
									                     <div class="one-third columns">
                    
                        <div class="item proyecto">
                        
                            <div class="jx-project-image">
                            
                                <div class="image imagen"><img src="galeria/proyectos-ejecucion/222119_agrolmos_Mesa de trabajo 1.jpg"></div>
                        		<!-- Image -->
                                <div class="image-hover"></div>
                                   
                                <div class="jx-percentage">
                                    <div  class="jx-count-up count-number porcentaje">100</div><span>%</span>
                                    <div class="progress">Progreso</div>
                                </div>
                            	<!--  Image hover Progress -->
                            </div>
                            <!-- Project Hover Image -->
                            
                            <div class="jx-project-contents">
                            
                            	<div class="title titulo">Automatización de Planta de Fertiducto </div>
                                <!-- Title -->
                                <div class="skillbar">
                                    <div class="percent-bg" style="width:100%;"></div>
                                </div>
                                <div class="description detalle" style="display:none;"><p>Culminamos el proyecto: <a href="https://www.facebook.com/hashtag/automatizaci%C3%B3n?__eep__=6&amp;__cft__[0]=AZV_VNJlMs4klWpj1igMDrmpskvYyJjudwhj6mCEdCiFuY0HovKxUJHeCaFPKzxCdLTA5bGQwCrhb6spz3Lpzzgp22siISv56K0Dxu49aqM0CD1iOsTTXIfl6icDZ9B9FSGTM6GIHMUZsyHCxq4_Xk9LDGyfjb7oYSnB-ZnJrkr_yuIBClBhllqgRA7WmwCVRgY&amp;__tn__=*NK-R">Automatización</a> de <a href="https://www.facebook.com/hashtag/planta?__eep__=6&amp;__cft__[0]=AZV_VNJlMs4klWpj1igMDrmpskvYyJjudwhj6mCEdCiFuY0HovKxUJHeCaFPKzxCdLTA5bGQwCrhb6spz3Lpzzgp22siISv56K0Dxu49aqM0CD1iOsTTXIfl6icDZ9B9FSGTM6GIHMUZsyHCxq4_Xk9LDGyfjb7oYSnB-ZnJrkr_yuIBClBhllqgRA7WmwCVRgY&amp;__tn__=*NK-R">Planta</a> de Fertiducto – <a href="https://www.facebook.com/hashtag/agrolmos?__eep__=6&amp;__cft__[0]=AZV_VNJlMs4klWpj1igMDrmpskvYyJjudwhj6mCEdCiFuY0HovKxUJHeCaFPKzxCdLTA5bGQwCrhb6spz3Lpzzgp22siISv56K0Dxu49aqM0CD1iOsTTXIfl6icDZ9B9FSGTM6GIHMUZsyHCxq4_Xk9LDGyfjb7oYSnB-ZnJrkr_yuIBClBhllqgRA7WmwCVRgY&amp;__tn__=*NK-R">Agrolmos</a>, con equipamiento Siemens.</p><div><div>Un importante proyecto ejecutado en la ciudad de <a href="https://www.facebook.com/hashtag/trujillo?__eep__=6&amp;__cft__[0]=AZV_VNJlMs4klWpj1igMDrmpskvYyJjudwhj6mCEdCiFuY0HovKxUJHeCaFPKzxCdLTA5bGQwCrhb6spz3Lpzzgp22siISv56K0Dxu49aqM0CD1iOsTTXIfl6icDZ9B9FSGTM6GIHMUZsyHCxq4_Xk9LDGyfjb7oYSnB-ZnJrkr_yuIBClBhllqgRA7WmwCVRgY&amp;__tn__=*NK-R">Trujillo</a>, Perú. Incluye diseño, ingeniería, Programación, Configuración, Comisionamiento y Puesta en Marcha&nbsp;</div></div></div>
                                <!-- Skillbar -->
    
                                <ul>
                                <li><strong>Cliente :</strong> <span class="cliente">AGROLMOS S.A.</span></li>
                                <li><strong>Localización :</strong> <span class="localizacion">Trujillo - Perú</span></li>
                                <li><strong>Año Exp:</strong> <span class="ano">2021</span></li>
                                </ul>
                            	<!-- Details -->                               
                            </div>
                            <!-- Right Position -->
                         
                        </div>                    
                        <!--Item -->
                    
                    </div>
									                     <!-- Item #3 --> 
                </div>
								              </div>
       </div>        
        <!-- EDF PROJECT IN PROGRESS--> 
        <div class="row"></div>
        <div class="row"></div>
        <!-- Process -->
        <div class="jx-container">
        <div class="parallax-no bg-pos-middle" style="background-image:url('images/stock-10.jpg');"></div>
        <!-- Parallax Background -->
        <div class="container">
            <div class="eight columns">
            	<div class="jx-process">
                <div class="jx-section-title-2">
                    <div class="jx-title jx-uppercase">Por qué elegirnos?</div>
                    <div class="jx-seperator-hr"></div>
                </div>
                <!-- Section Title -->
                <ul>
                <li>
                    <div class="jx-process-item">
                        <div class="jx-process-step"><div>1</div></div>
                        <div class="jx-process-content">
                            <div class="jx-process-title">Experiencia y conocimiento en sectores</div>
                            <div class="jx-process-description">Bebidas y alimentos, cementos, minería, saneamiento y sucro alcoholero.</div>
                        </div>
                    </div>
                </li>
                <!-- Item 01 -->
				<li>
                    <div class="jx-process-item">
                        <div class="jx-process-step"><div>2</div></div>
                        <div class="jx-process-content">
                            <div class="jx-process-title">Empresa multinacional</div>
                            <div class="jx-process-description">Desde el año 1997 dedicados a brindar soluciones integrales de modernización y automatización industrial.</div>
                        </div>
                    </div>
                </li>
                <!-- Item 02 -->
                <li>
                    <div class="jx-process-item">
                        <div class="jx-process-step"><div>3</div></div>
                        <div class="jx-process-content">
                            <div class="jx-process-title">Proyectos llave en mano PMI</div>
                            <div class="jx-process-description">Proveemos soluciones integrales de automatización, que permiten que sean mas rápidos, eficientes, confiables y económicos.</div>
                        </div>
                    </div>
                </li>
                <!-- Item 03 -->
                <li class="vertical-line"></li>
                </ul>
            </div>
            </div>
        </div>
        </div>
        </div>
        <div class="row"></div>
        <!-- BDF OUR ALIANZAS & CAPACITACIONES -->
        <div class="jx-container jx-padding jx-white-bg">
            <div class="container">
<div class="jx-section-title-1">            

                    <div class="jx-seperator-icon"><i class="fa fa-chevron-down"></i></div>
                    <div class="jx-title-position">
                        <div class="jx-left-border"></div>
                        <div class="jx-title jx-uppercase">Marcas que comercializamos</div>
                        <div class="jx-right-border"></div>
                    </div>
                    <div class="jx-subtitle">El respaldo de compañías internacionales, avalan nuestra trayectoria, profesionalismo y constante modernización en procesos industriales</div>  
                </div> 
                <!-- Section Title --> 
                 <div class="jx-partner-logo">
                     <ul>
                        <li><img src="images/siemens.jpg" alt="siemens"/></li>
                        <li><img src="images/rockwell.jpg" alt="rockell"/></li>
                        <li><img src="images/matrikon.jpg" alt="matrikon"/></li>
                        <li><img src="images/rittal.jpg" alt="rittal"/></li>
                        <li><img src="images/phoenix.jpg" alt="phoenix"/></li>
                        </ul>
                 </div>
            </div>
        </div>       
        <!-- EDF OUR CLIENT-->
        <div class="row"></div>
         <!--  BOF TAGLINE ACTION BOX  # 2 -->
    	<div class="jx-container jx-default-bg">
        <div class="jx-container">
            <div class="jx-tagline-box">
                <div class="container"> 
                        <div class="five columns box-content">
                            <h2>Oficinas en</h2>
                            <h3>Perú y Bolivia</h3>
                        </div>
                    <!-- Content -->
                    	<div class="jx-line-seperator"></div>
                    	<div class="eleven columns jx-subscribeletter">
                        	<h2>Suscríbete al boletin de noticias</h2>
                        	<form method="post" onsubmit="return false;" id="f-boletin">
                            	<div class="jx-newsletter-box">
                                <input type="text" name="jx-newsltter-name" class="nombre" placeholder="Nombres" value="" required />
                                </div>
                                <div class="jx-newsletter-box">
                                <input type="email" name="jx-newsltter-email" class="email" placeholder="Email" value="" required />
                                </div>
                                <div class="jx-newsletter-submit">

                                <input type="submit" name="jx-newsltter-submit" value="Ir" />

                                </div>
							</form>
                        </div>
                </div>
            </div>              
        </div>
    </div>
    	<!--  BOF TAGLINE ACTION BOX  # 2 -->  
    </div>
    <!-- EOF Main Content -->
    <!-- BOF FOOTER -->
    <footer class="jx-footer-section">
		<div class="jx-footer-1">        
           <!-- BDF widget FOOTER -->        
            <div class="jx-footer jx-container">
                <div class="container">
                    <!-- BOF Footer widget #1 -->
                    <div class="four columns">
                        <div class="widget">             
                            <div class="jx-about">
                                <div class="jx-footer-title">Certificaciones</div>
                            <!-- Content -->
                            <img src="images/sgs-logo.png" alt="sgs" />
                            <img src="images/bureau_logo.png" alt="dinaut" /> 
                            </div>
                         </div>
                        <!-- Newsletter Subscribe -->
                    </div>                
                    <!-- EOF Footer widget #1 -->
                    <!-- BOF Footer widget #2-->
                    <div class="four columns">
                    	<div class="widget">
                            <div class="jx-footer-title">Bolsa Laboral</div>
                            <!-- widget Title -->
                            <div class="jx-widget-recent-post">

                                <ul>
                                   <li>
                                       <div class="image"><img src="images/bolsa-laboral.jpg" alt="bolsa-laboral" /></div>
                                         <div class="post-content">
                                            <div class="date">Nos gustaria que seas parte de nuestro equipo. Déjenos sus datos ahora.</div>
                                            </div>
                                    </li>
                                </ul>
                               <div class="jx-btn jx-black"> 
                                    <a href="bolsa_laboral.php" class="jx-btn-default">
                                       <span>	
                                            <i class="btn-icon-left fa fa-mail-forward"></i>
                                            <span>Postular</span>
                                            <i class="btn-icon-right fa fa-mail-forward"></i>
                                        </span>
                                    </a>
                            	</div>
                            </div>
                            <!-- Recent Post -->
                        </div>
                    </div>                
                    <!-- EOF Footer widget #2-->
                    <!-- BOF Footer widget #3 -->
                    <div class="four columns">
                          <div class="widget">                
                            <div class="jx-footer-title">Video</div>
                            <iframe src="https://player.vimeo.com/video/216543715" width="640" height="160" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>
<p><a href="https://vimeo.com/216543715">Solution Partner Siemens - Dinaut</a>.</p>                 
						</div>
                      </div>                
                    <!-- EOF Footer widget #3-->
                    <!-- BOF Footer widget #4 -->
                    <div class="four columns">
                          <div class="widget">
                            <div class="jx-footer-title">Contacto Perú</div>
                            <!-- widget Title -->                         
                            <div class="jx-footer-address">
                               <ul>
                                    <li>
                                    <i class="line-icon icon-location"></i>
                                    <div>Av. Aurelio Garcia y Garcia 1592, Lima 01</div>
                                    </li>
                                    <li>
                                    <i class="line-icon icon-mobile"></i>
                                    <div class="tel"><strong>Tel :</strong> +51 (1) 564 - 5521</div>
                                    </li>
                                    <li>
                                    <i class="line-icon icon-globe"></i>
                                    <div class="email"><strong>Email :</strong> mail@dinaut.com</div>
                                    </li>
                                </ul>
                           </div>
                            <!-- Contact Address -->
                        </div>                                         
                    </div>                  
                    <!-- EOF Footer widget #4 -->
                </div>
            </div>
            <!-- EDF widget FOOTER -->
            <!-- BDF SUB FOOTER -->        
            <div class="jx-sub-footer jx-container">
                <div class="container"> 
                    <div class="eight columns">
                        <div class="jx-copy-right">Copyright © 2020 Diseñado por <a href="http://atipica.pe" target="_blank">Atípica</a></div>
                    </div>                
					<!-- Copyright Text -->
                    <div class="eight columns">
                       <div class="jx-footer-social-icon">
                        <ul>                            
                            <li class="facebook">
                            <a href="https://www.facebook.com/Dinautomatizacion" target="_blank"><i class="fa fa-facebook"></i></a>
                            </li>                        
                            <li class="instagram">
                            <a href="https://www.instagram.com/dinaut_peru/" target="_blank"><i class="fa fa-instagram"></i></a>
                            </li>
                            <li class="youtube">
                            <a href="http://www.youtube.com/#" target="_blank"><i class="fa fa-youtube"></i></a>
                            </li>
                            <li class="googleplus">
                            <a href="http://www.googleplus.com/#" target="_blank"><i class="fa fa-google-plus"></i></a>
                            </li>
                        </ul>
                     </div>
                    </div>
                    <!-- Social Icons -->                
                </div>
            </div>
            <!-- EDF SUB FOOTER -->        
        </div>        
    </footer>
    <!-- EOF FOOTER -->
    <!-- Footer -->
	<script type="text/javascript" src="vendor/jquery.js"></script>
    <script type="text/javascript" src="js/plugins.js"></script>
	<script type="text/javascript" src="vendor/respond.js"></script>
    <script type="text/javascript" src="vendor/jquery.appear.js"></script>    
    <script type="text/javascript" src="vendor/prettyPhoto/jquery.prettyPhoto.js"></script>
    <script type="text/javascript" src="vendor/isotope/jquery.isotope.min.js"></script>
	<script type='text/javascript' src='vendor/form-validator/jquery.form-validator.min.js'></script>
    <script type="text/javascript" src="vendor/flexslider/jquery.flexslider.js"></script>	
    <script type="text/javascript" src="vendor/rs-plugin/js/jquery.themepunch.tools.min.js"></script>
    <script type="text/javascript" src="vendor/rs-plugin/js/jquery.themepunch.revolution.min.js"></script>
	
	
   <!-- Home JS -->
	<script src="js/custom/home.js"></script>
    <!-- Theme Initializer -->
	<script src="js/theme.js"></script>
	<script>
	$.fn.extend({
    animateCss: function (animationName) {
        var animationEnd = 'webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend';
        this.addClass('animated ' + animationName).one(animationEnd, function() {
            $(this).removeClass('animated ' + animationName);
        });
    }
	});
		
	$(function(){
		$('#f-boletin').submit(function(){
			var nombre = $('#f-boletin .nombre').val();
			var email = $('#f-boletin .email').val();
			var data = {'nombre':nombre,'email':email};
			$.post('include/submit-boletin.php',data,function(resp){
				console.log(resp);
				if(resp.error){
					alert('Hubo un error al registrar su correo.');
				}else{
					alert('Se ha suscrito correctamente');
					$('#f-boletin .nombre').val('');
					$('#f-boletin .email').val('');
				}
			},'json');
			
			return false;
		});
		
		$('.item.proyecto').click(function(){ console.log('click');
			var item_titulo = $('.titulo',this).html();
			var item_imagen = $('.imagen',this).html();
			var item_porcentaje = $('.porcentaje',this).html();
			var item_detalle = $('.detalle',this).html();
			var item_cliente = $('.cliente',this).html();
			var item_localizacion = $('.localizacion',this).html();
			var item_ano = $('.ano',this).html();
																				 
			var destacado_titulo = $('.item-destacado .titulo').html();
			var destacado_imagen = $('.item-destacado .imagen').html();
			var destacado_porcentaje = $('.item-destacado .porcentaje').html();
			var destacado_detalle = $('.item-destacado .detalle').html();
			var destacado_cliente = $('.item-destacado .cliente').html();
			var destacado_localizacion = $('.item-destacado .localizacion').html();
			var destacado_ano = $('.item-destacado .ano').html();				
																				 
			$('.item-destacado').animateCss('flipInY');
																				 
			$('.item-destacado .titulo').html(item_titulo);
			$('.item-destacado .imagen').html(item_imagen);
			$('.item-destacado .porcentaje').html(item_porcentaje);
			$('.item-destacado .detalle').html(item_detalle);
			$('.item-destacado .cliente').html(item_cliente);
			$('.item-destacado .localizacion').html(item_localizacion);
			$('.item-destacado .ano').html(item_ano);
																				 
		 	$('.titulo',this).html(destacado_titulo);
			$('.imagen',this).html(destacado_imagen);
			$('.porcentaje',this).html(destacado_porcentaje);
			$('.detalle',this).html(destacado_detalle);
			$('.cliente',this).html(destacado_cliente);
			$('.localizacion',this).html(destacado_localizacion);
			$('.ano',this).html(destacado_ano);
																				 
		 	$('.item-destacado').animateCss('flipInY');
			$(this).animateCss('fadeIn');
		
			
		});
	});
	</script>
  <!-- WhatsHelp.io widget -->
<script type="text/javascript">
    (function () {
        var options = {
            whatsapp: "+51997598006", // WhatsApp number
            call_to_action: "Contáctanos", // Call to action
            position: "right", // Position may be 'right' or 'left'
        };
        var proto = document.location.protocol, host = "whatshelp.io", url = proto + "//static." + host;
        var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = url + '/widget-send-button/js/init.js';
        s.onload = function () { WhWidgetSendButton.init(host, proto, options); };
        var x = document.getElementsByTagName('script')[0]; x.parentNode.insertBefore(s, x);
    })();
</script>
<!-- /WhatsHelp.io widget --></body>
</html>