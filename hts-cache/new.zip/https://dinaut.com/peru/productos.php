<!DOCTYPE html>
<!--[if lt IE 7 ]><html class="ie ie6" lang="es"> <![endif]-->
<!--[if IE 7 ]><html class="ie ie7" lang="es"> <![endif]-->
<!--[if IE 8 ]><html class="ie ie8" lang="es"> <![endif]-->
<!--[if (gte IE 9)|!(IE)]><!--><html lang="es"> <!--<![endif]-->
<head>
	<!-- Basic Page Needs
  ================================================== -->
	<meta charset="utf-8">
	<title>DINAUT | Productos</title>
	<meta name="keywords" content="productos de automatizacion, productos dinaut, siemens peru, productos industriales, instrumentacion industrial, fuentes de alimentacion">
    <meta name="description" content="Productos de automatizacion industrial">
	<meta name="author" content="atipica.pe">
	
    <!-- Mobile Specific Metas
  ================================================== -->
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
	<!-- CSS
  ================================================== -->
	
    <!-- Web Fonts  -->
    <link href='https://fonts.googleapis.com/css?family=Raleway:400,700,600,500,300' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Oswald:400,700,300' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,700,600,500,300' rel='stylesheet' type='text/css'>
    
    <!-- Theme Style -->
    <link rel="stylesheet" href="css/theme.css">   
    <link rel="stylesheet" href="css/theme-animate.css">   
    <link rel="stylesheet" href="css/theme-elements.css">   
    <link rel="stylesheet" href="css/plugins.css">    
    
    <!-- Skin CSS -->
	<link id="skin" rel="stylesheet" href="css/skins/sun.css">
    <!-- Icon Fonts -->
    <link rel='stylesheet' href='fonts/font-awesome.min.css' type='text/css' media='screen' />    
    
    <!-- Library Css -->
    <link rel="stylesheet" href="css/skeleton.css"> 
    <link rel="stylesheet" href="vendor/flexslider/flexslider.css">
    
    <link rel="stylesheet" href="vendor/isotope/isotope.css">
    <link rel="stylesheet" href="vendor/owl/owl.carousel.css">
    <link rel="stylesheet" href="vendor/prettyPhoto/prettyPhoto.css">
    <link rel="stylesheet" type="text/css" href="vendor/rs-plugin/css/settings.css" media="screen" /> 
    
    <!-- Responsive Theme -->
    <link rel="stylesheet" href="css/theme-responsive.css">
    
    <!-- Library Js -->
	<script src="vendor/modernizr.js"></script>
    
    <!-- Google Map -->
    <script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=false"></script>
    
    <!--[if IE]>
        <link rel="stylesheet" href="css/ie.css">
    <![endif]-->
    
    <!--[if lte IE 8]>
        <script src="vendor/respond.js"></script>
    <![endif]-->
    
	<!--[if lt IE 9]>
		<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
	<!-- Favicons
	================================================== -->
	<link rel="shortcut icon" href="images/favicon.png">
	<link rel="apple-touch-icon" href="images/apple-touch-icon.png">
	<link rel="apple-touch-icon" sizes="72x72" href="images/apple-touch-icon-72x72.png">
	<link rel="apple-touch-icon" sizes="114x114" href="images/apple-touch-icon-114x114.png">

    <style type="text/css">
    .port-box-text {
      background: #7b7b7b;
      padding: 15px;
      color: #fff;
    }
    .port-box-text .category {
        font-weight: bold;
        font-size: 16px;
    }
    .port-box-text .discription {}
    .port-box-text .discription ul {
      margin-top: 15px;
      padding-left: 15px;
    }
    .port-box-text .discription ul li {
      margin-bottom: 5px;
      list-style-type: circle;
      list-style-position: outside;
    }
    </style>

</head>  
<body>
	<!-- BOF Loader -->
     <div class="loader">
         <div class="spinner spinner-double-bounce">
              <div class="double-bounce1"></div>
              <div class="double-bounce2"></div>
         </div>
	</div>
    <!-- EOF Loader -->
    
    <!-- BOF Header -->   
    <header>
        <!-- BOF Top Bar -->
        <div class="jx-header-1">
            <!-- BDF TOOLBAR -->
            <div class="jx-topbar">
                <div class="container">
                    <div class="eight columns left">
                        <div class="jx-left-topbar">DIN Automatización | Soluciones integrales</div>
                    </div>
                    <!-- Left Items -->
                    <div class="eight columns right">
                        <div class="jx-right-topbar">
                            <div class="email left"><i class="fa fa-envelope"></i> mail@dinaut.com</div>
                                <ul class="right">
                                    <li><a href="./admin" target="_blank"><i class="fa fa-user"></i>Acceso Usuarios</a>&nbsp;</li>
								    <li><a href="#"><i class="fa fa-google-plus"></i></a></li>
                                </ul>
                                <!-- Social icons-->
                            </div>
                    </div>
                    <!-- Right Items -->
                </div>
            </div>
            <!-- EDF TOOLBAR --> 
            <div class="jx-header header-line">
                <div class="container">
                    <div class="four columns">
                        <div class="jx-header-logo">
                            <a href="index.php"><img src="images/logo1.png" alt="dinaut" /></a>
                         </div>
                        <!-- Logo -->
                    </div>                
                    <div class="twelve columns">
                        <div class="header-info">
                            <ul>
                                <li class="top-space">
                                <div class="icon"><i class="fa fa-map-marker"></i></div>
                                <div class="position">
                                <div class="location">Oficinas</div>
                                <div class="address">PERÚ, BOLIVIA</div>
                                </div>
                                </li>
                                <li class="top-space">
                                <div class="icon"><i class="fa fa-clock-o"></i></div>
                                <div class="position">
                                <div class="time">Horario en Oficina</div>
                                <div class="date">LUN - VIE 7:45 - 17:15</div>
                                </div>
                                </li>
                                <li>
                                    <div class="toll-free-number"> <img src="images/siemens-logo.png"></div>
                                </li> 
                            </ul>
                        </div>
                        <!-- Header Info -->
                    </div>                
	            </div>
            </div>     
        </div>
        <!-- EOF Top Bar -->
        <!-- EDF Header -->
        
        <div class="jx-menu-holder jx-sticky">
        	<div class="container">
                    <div class="header-menu-left">
                      <div class="nav_container">
                            
<ul id="jx-main-menu" class="menu">

	<!-- Item 1 -->

	<li class=""><a href="./index.php" >Inicio</a></li>       

	<!-- Item 2 -->

	<li><a href="./nosotros.php">Nosotros</a></li>

	<!-- Item 3 -->

	<li class="with-sub">

		<a href="#">Nuestra oferta</a>

		<ul class="submenu">     

			<li class="">

				<a href="./productos.php">Productos</a>

			</li>

			<li class="has-child">

				<a href="#">Servicios</a>

				<ul class="submenu">                                        					                                  	                                     

						<li><a href="./montaje_conexiones_electricas.php">Montaje y Conexiones<br> El&eacute;ctricas</a></li>

						<li><a href="./ingenieria_basica_detalle.php">Ingenier&iacute;a B&aacute;sica y de Detalle</a></li>

						<li><a href="./ingenieria_desarrollo_aplicaciones.php">Ingenier&iacute;a de Desarrollo y de<br> Aplicaciones</a></li>

						<li><a href="./comisionamiento_puesta_marcha.php">Comisionamiento y Puesta<br> en Marcha</a></li>

						<li><a href="./proyectos.php">Proyectos</a></li>

						<li><a href="./entrenamiento.php">Entrenamiento</a></li>

				</ul>

			 </li>

		 </ul>

	</li>

	<!-- Item 3 -->

			<li class="with-sub">
			<a href="./proyectos.php">Proyectos</a>
			<ul class="submenu lista-servicio">
				<li><a href="./proyectos.php#agroindustrial" data-filter=".agroindustrial" data-servicio="agroindustrial">Agroindustrial</a></li>
				<li><a href="./proyectos.php#bebidas" data-filter=".bebidas" data-servicio="bebidas">Industria</a></li>
				<li><a href="./proyectos.php#mineria" data-filter=".mineria" data-servicio="mineria">Miner&iacute;a</a></li>
				<li><a href="./proyectos.php#saneamiento" data-filter=".saneamiento" data-servicio="saneamiento">Saneamiento</a></li>
				<li><a href="./proyectos.php#educativo" data-filter=".educativo" data-servicio="educativo">Educaci&oacute;n</a></li>
			</ul>  
		</li>
	
	 <!-- Item 4 -->  

	<li><a href="./entrenamiento.php">Entrenamiento</a></li>

	<!-- Item 5 -->

	<li class="with-sub">

		<a href="#">Contacto</a>

		<ul class="submenu">                                    	                                       

					<li ><a href="./contacto.php">Oficina Per&uacute;</a></li>

					<li ><a href="./contacto_bolivia.php">Oficina Bolivia</a></li>

					<!--<li ><a href="./contacto_ecuador.php">Oficina Ecuador</a></li>-->

					<li ><a href="./bolsa_laboral.php">Bolsa laboral</a></li>

		 </ul>  

	</li>

  </ul>

</div>                                             	                 
                        </div>
                        <!-- EOF Menu -->
                    </div>
                    <!-- MENU -->
                    </div>
    	</div>
        <!-- BOF Main Menu -->
     <br>   
	</header>         
    
    <!-- EOF Main Menu -->
    
    <!-- BOF Main Content -->
    <div role="main" class="main no-top-padding">
      
        <!-- BDF TABS -->
        
        <div class="jx-container jx-white-bg jx-padding">
            <div class="container"> 
            <div class="row"></div>
    		<div class="row"></div>
              <div class="jx-section-title-1">            
                    <div class="jx-seperator-icon"><i class="fa fa-chevron-down"></i></div>
                    <div class="jx-title-position">
                        <div class="jx-left-border"></div>
                        <div class="jx-title">PRODUCTOS</div>
                        <div class="jx-right-border"></div>
                    </div>
                    <div class="jx-subtitle">Especiales para automatización, control y construcción de cada proyecto y necesidad del cliente</div>  
                </div> 
                <!-- Section Title -->                      
                
                <div class="row"></div>
                
                <div class="eight columns">
                <img id="productyo_image_src" src="images/producto1.jpg" />
                </div>
                <!-- According -->
                
                <div class="eight columns">
                    
                    
                   <div class="shortcode_tab_e jx-white-tab jx-arrow-tab">
                        <div id="horizontalTab-5">
                          <ul class="resp-tabs-list">
                             <li class="resp-tab-item tab-image-clic" data-image="images/producto1.jpg">
                                <div class="jx-tab-bubble"></div>
                                <div class="jx-tab-title">Automatización</div>
                             </li>
                             <li class="resp-tab-item tab-image-clic" data-image="images/instrumentacion.jpg">
                                <div class="jx-tab-bubble"></div>
                                <div class="jx-tab-title">Instrumentos Industriales</div>
                             </li>
                             <li class="resp-tab-item tab-image-clic" data-image="images/maniobra.jpg">
                                <div class="jx-tab-bubble"></div>
                                <div class="jx-tab-title">Maniobra</div>
                             </li>
                             <li class="resp-tab-item tab-image-clic" data-image="images/productos/modulo-educativo.jpg">
                                <div class="jx-tab-bubble"></div>
                                <div class="jx-tab-title">Módulos educativos</div>
                             </li>
                          </ul>
                          <!-- Headings -->
                          
                          
                          <div class="resp-tabs-container">
                             <div class="tab-content resp-tab-content">
                        <p>
                            * Sistemas de control distribuido PCS7, CEMAT, BRAUMAT<br>
                            * Sistemas de seguridad de procesos y de maquinas F<br>
                            * Sistemas de control para procesos discontinuos o por lotes Batch, BRAUMAT.
                        </p>
                             </div>
                             <!-- Item#1 -->
                             <div class="tab-content resp-tab-content">
                             <p>* Nivel<br>
                                * Flujo<br>
                                * Presión<br>
                                * Temperatura<br>
                                * Posicionadores</p>
                             </div>
                             <!-- Item#2 -->
                             
                             <div class="tab-content resp-tab-content">
                             <p>* Contactores, guardamotores y arrancadores suaves<br>
                                * Pulsadores y lámparas<br>
                                * Llaves termomagnéticas<br>
                                * Relés inteligentes<br>
                                * Pulsadores y conmutadores<br>
								* Avisos luminosos y acústicos</p>
                             </div>
                             <!-- Item#3 -->
                             
                             <div class="tab-content resp-tab-content">
                             <p><strong>Plantas de procesos con fines educativos</strong><br>
                                * Plantas de control de procesos de una variable<br>
                                * Plantas de control de procesos multivariable</p>
                             </div>
                             <!-- Item#4 -->
                             
                          </div>
                          <!-- Tab Contents -->
                          
                        </div>
                    <!-- Horizontal Tab -->
                    <div class="mb60"></div>
                    </div> 
                    
                    
                                                            
                </div>
                <!-- Tabs -->
                
            </div>
        </div>
        <!-- EDF TABS -->
        <div class="jx-container jx-white-bg jx-padding">
            <div class="parallax-no bg-pos-middle" style="background-image:url('images/fondo-productos.jpg');"></div>
            <div class="container">
             <div class="jx-section-title-1"> 
              <div class="row"></div>
    <div class="row"></div>
    <div class="row"></div>           
                    <div class="jx-seperator-icon"><i class="fa fa-chevron-down"></i></div>
                    <div class="jx-title-position">
                        <div class="jx-left-border"></div>
                        <div class="jx-title jx-white">COMPLEMENTO DE PRODUCTOS</div>
                        <div class="jx-right-border"></div>
                    </div>
                    <div class="jx-subtitle jx-white">El complemento perfecto para ejecución de proyectos</div>  
                </div> 
                <!-- Section Title --> 
               
            </div>
        </div>
        
    </div>
    <div role="main" class="main no-top-padding">
    
   		<div class="jx-container jx-padding">
        	<div class="sixteen columns">
            
<!-- Portfolio -->
<div class="jx-protfolio">
    <!--Category Menu -->
    <div class="jx-portfolio-grid">

        <div class="port-box-image grid-item grid-item-width2 grid-item-height2 jx-image-wrapper construction maintenance all">
            <img src="images/productos/8.jpg" alt="">
        </div>
        <div class="port-box-text grid-item grid-item-width2 grid-item-height2 jx-image-wrapper maintenance all"><br>
            <div class="item-position">
                <div class="category">Automatización de fábricas y maquinas</div>
                <!-- Title -->
                <div class="discription">
                    <ul>
                        <li>Controladores lógicos programables (PLC’s)</li>
                        <li>Interfases hombre máquina (HMI’s) y SCADA</li>
                        <li>Periferia descentralizada y distribuida</li>
                        <li>Comunicación y redes industriales</li>
                        </ul>
                </div>
            </div>
        </div>

        <div class="port-box-image grid-item grid-item-width2 grid-item-height2 jx-image-wrapper interior woodwork all">
            <img src="images/productos/2.jpg" alt="">
        </div>
        <div class="port-box-text grid-item grid-item-width2 grid-item-height2 jx-image-wrapper maintenance all"><br>
            <div class="item-position">
                <br><br>
                <!-- Title -->
                <div class="discription">
                    <ul>
                        <li>Computadoras industriales</li>
                        <li>Softwares de automatización y control de procesos</li>
                    </ul>
                </div>
            </div>
        </div>

        <div class="port-box-image grid-item grid-item-width2 grid-item-height2 jx-image-wrapper interior woodwork all">
            <img src="images/productos/3.jpg" alt="">
        </div>
        <div class="port-box-text grid-item grid-item-width2 grid-item-height2 jx-image-wrapper maintenance all"><br>
            <div class="item-position">
                <div class="category"> Potencia y motores</div>
                <!-- Title -->
                <div class="discription">
                    <ul>
                        <li>Arrancadores</li>
                        <li>Variadores de velocidad</li>
                        <li>Motoreductores</li>
                        <li>Controly gestión de motores SIMOCODE</li>
                        <li>Motores trifásicos IEC y NEMA</li>
                       </ul>
                </div>
            </div>
        </div>

        <div class="port-box-image grid-item grid-item-width2 grid-item-height2 jx-image-wrapper painting woodwork all">
            <img src="images/productos/7.jpg" alt="">
        </div>
        <div class="port-box-text grid-item grid-item-width2 grid-item-height2 jx-image-wrapper maintenance all"><br>
            <div class="item-position">
                <div class="category"> Módulos educativos</div>
                <!-- Title -->
                <div class="discription">
                    <ul>
                        <li>Módulos con PLC</li>
                        <li>Módulos con HMI</li>
                        <li>Módulos con redes industriales</li>
                        <li>Módulos con máquinas y maniobras eléctricas</li>
                        <li>Módulos con máquinas rotativas en AC y DC</li>
                        </ul>
                </div>
            </div>
        </div>

        <div class="port-box-image grid-item grid-item-width2 grid-item-height2 jx-image-wrapper painting woodwork all">
            <img src="images/productos/5.jpg" alt="">
        </div>
        <div class="port-box-text grid-item grid-item-width2 grid-item-height2 jx-image-wrapper maintenance all">
            <div class="item-position">
                <div class="category"> Maniobra, protección y señalización</div>
                <!-- Title -->
                <div class="discription">
                    <ul>
                        <li>Contactores, guardamotores y arrancadores suaves</li>
                        <li>Pulsadores y lámparas</li>
                        <li>Llaves termomagnéticas</li>
                        <li>Relés inteligentes</li>
                        <li>Pulsadores y conmutadores</li>
                        <li>Avisos luminosos y acústicos</li>
                    </ul>
                </div>
            </div>
        </div>
        
        <div class="port-box-image grid-item grid-item-width2 grid-item-height2 jx-image-wrapper painting woodwork all">
            <img src="images/productos/6.jpg" alt="">
        </div>
        <div class="port-box-text grid-item grid-item-width2 grid-item-height2 jx-image-wrapper maintenance all"><br>
            <div class="item-position">
                <div class="category"> Cajas y Armarios</div>
                <!-- Title -->
                <div class="discription">
                    <ul>
                        <li>Armarios metálicos, poliester y de plásticos auto soportados y de fijación mural</li>
                        <li>Armarios IT - Adosables y auto soportados</li>
                        <li>Climatización de sistemas</li>
                        </ul>
                </div>
            </div>
        </div>
        <div class="port-box-image grid-item grid-item-width2 grid-item-height2 jx-image-wrapper painting woodwork all">
            <img src="images/productos/10.jpg" alt="">
        </div>
        <div class="port-box-text grid-item grid-item-width2 grid-item-height2 jx-image-wrapper maintenance all"><br>
            <div class="item-position">
                <div class="category"> Instrumentos de medición</div>
                <!-- Title -->
                <div class="discription">
                    <ul>
                        <li>Medidores multifunción</li>
                        <li>Analizadores y voltímetros digitales / analógicos</li>
                        <li>Contadores de energía y medidores de fase</li>
                        <li>Transformadores de corriente</li>
                        </ul>
                </div>
            </div>
        </div>
        <div class="port-box-image grid-item grid-item-width2 grid-item-height2 jx-image-wrapper painting woodwork all">
            <img src="images/productos/9.jpg" alt="">
        </div>
    </div>      
</div>
<!-- EOF Portfolio -->
            
            </div>
        </div>
    </div>
    <!-- EOF Main Content -->
    
    
    <!-- BOF FOOTER -->
    
    <footer class="jx-footer-section">
		<div class="jx-footer-1">        
           <!-- BDF widget FOOTER -->        
            <div class="jx-footer jx-container">
                <div class="container">
                    <!-- BOF Footer widget #1 -->
                    <div class="four columns">
                        <div class="widget">             
                            <div class="jx-about">
                            <div class="jx-footer-title">Certificaciones</div>
                            <img src="images/sgs-logo.png" alt="sgs" />
                            <img src="images/bureau_logo.png" alt="dinaut" /> 
                            <!-- Content -->
                            </div>
                         </div>
                        <!-- Newsletter Subscribe -->
                    </div>                
                    <!-- EOF Footer widget #1 -->
                    <!-- BOF Footer widget #2-->
                    <div class="four columns">
                    	<div class="widget">
                            <div class="jx-footer-title">Bolsa Laboral</div>
                            <!-- widget Title -->
                            <div class="jx-widget-recent-post">

                                <ul>
                                   <li>
                                       <div class="image"><img src="images/bolsa-laboral.jpg" alt="bolsa-laboral" /></div>
                                         <div class="post-content">
                                            <div class="date">Nos gustaria que seas parte de nuestro equipo. Déjenos sus datos ahora.</div>
                                            </div>
                                    </li>
                                </ul>
                               <div class="jx-btn jx-black"> 
                                    <a href="bolsa_laboral.php" class="jx-btn-default">
                                       <span>	
                                            <i class="btn-icon-left fa fa-mail-forward"></i>
                                            <span>Postular</span>
                                            <i class="btn-icon-right fa fa-mail-forward"></i>
                                        </span>
                                    </a>
                            	</div>
                            </div>
                            <!-- Recent Post -->
                        </div>
                    </div>                
                    <!-- EOF Footer widget #2-->
                    <!-- BOF Footer widget #3 -->
                    <div class="four columns">
                          <div class="widget">                
                            <div class="jx-footer-title">Video</div>
                            <iframe src="https://player.vimeo.com/video/216543715" width="640" height="160" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>
<p><a href="https://vimeo.com/216543715">Solution Partner Siemens - Dinaut</a>.</p>              
						</div>
                      </div>                
                    <!-- EOF Footer widget #3-->
                    <!-- BOF Footer widget #4 -->
                    <div class="four columns">
                          <div class="widget">
                            <div class="jx-footer-title">Contacto Perú</div>
                            <!-- widget Title -->                         
                            <div class="jx-footer-address">
                               <ul>
                                    <li>
                                    <i class="line-icon icon-location"></i>
                                    <div>Av. Aurelio Garcia y Garcia 1592, Lima 01</div>
                                    </li>
                                    <li>
                                    <i class="line-icon icon-mobile"></i>
                                    <div class="tel"><strong>Tel :</strong> +51 (1) 564 - 5521</div>
                                    </li>
                                    <li>
                                    <i class="line-icon icon-globe"></i>
                                    <div class="email"><strong>Email :</strong> mail@dinaut.com</div>
                                    </li>
                                </ul>
                           </div>
                            <!-- Contact Address -->
                        </div>                                         
                    </div>                  
                    <!-- EOF Footer widget #4 -->
                </div>
            </div>
            <!-- EDF widget FOOTER -->
            <!-- BDF SUB FOOTER -->        
            <div class="jx-sub-footer jx-container">
                <div class="container"> 
                    <div class="eight columns">
                        <div class="jx-copy-right">Copyright © 2019 Diseñado por <a href="http://atipica.pe" target="_blank">Atípica</a></div>
                    </div>                
					<!-- Copyright Text -->
                    <div class="eight columns">
                       <div class="jx-footer-social-icon">
                        <ul>                            
                            <li class="facebook">
                            <a href="http://www.facebook.com/#" target="_blank"><i class="fa fa-facebook"></i></a>
                            </li>                        
                            <li class="twitter">
                            <a href="http://www.twitter.com/#" target="_blank"><i class="fa fa-twitter"></i></a>
                            </li>
                            <li class="youtube">
                            <a href="http://www.youtube.com/#" target="_blank"><i class="fa fa-youtube"></i></a>
                            </li>
                            <li class="googleplus">
                            <a href="http://www.googleplus.com/#" target="_blank"><i class="fa fa-google-plus"></i></a>
                            </li>
                        </ul>
                     </div>
                    </div>
                    <!-- Social Icons -->                
                </div>
            </div>
            <!-- EDF SUB FOOTER -->        
        </div>        
    </footer>
     
    <!-- EOF FOOTER -->

    
        
    <!-- Footer -->
    
	<script type="text/javascript" src="vendor/jquery.js"></script>
    <script type="text/javascript" src="js/plugins.js"></script>
	<script type="text/javascript" src="vendor/respond.js"></script>
    <script type="text/javascript" src="vendor/jquery.appear.js"></script>    
    <script type="text/javascript" src="vendor/prettyPhoto/jquery.prettyPhoto.js"></script>
    <script type="text/javascript" src="vendor/isotope/jquery.isotope.min.js"></script>
    <script type='text/javascript' src='vendor/form-validator/jquery.form-validator.min.js'></script>
    <script type="text/javascript" src="vendor/flexslider/jquery.flexslider.js"></script>	
    <script type="text/javascript" src="vendor/rs-plugin/js/jquery.themepunch.tools.min.js"></script>
    <script type="text/javascript" src="vendor/rs-plugin/js/jquery.themepunch.revolution.min.js"></script>
    
   <!-- Home JS -->
	<script src="js/custom/home.js"></script>
    
    <!-- Theme Initializer -->
	<script src="js/theme.js"></script>

<!-- Custom JS -->    
<script type="text/javascript">
    $(document).ready(function(){

        $(".tab-image-clic").click(function() {
            $(this).fadeOut('');
            var data_image = $(this).attr("data-image");
            $('#productyo_image_src').attr("src",data_image);
            $(this).fadeIn('');
        });

    });
    $(window).load(function(){

        var port_box_image_W = $(".port-box-image").outerWidth();
        var port_box_image_h = $(".port-box-image").outerHeight();

        $(".port-box-text").css({
            "width": port_box_image_W,
            "height": port_box_image_h
        });

    });
    $(window).resize(function(){
        
        var port_box_image_W = $(".port-box-image").outerWidth();
        var port_box_image_h = $(".port-box-image").outerHeight();

        $(".port-box-text").css({
            "width": port_box_image_W,
            "height": port_box_image_h
        });

    });
</script>    
    
</body>
</html>